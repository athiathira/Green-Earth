<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action=""method="POST"><br>
     <label>DonorName:</label><input type="text"name="donor_name" class='form-control'><br>
     <label>email:</label><input type="text" name="email"class='form-control'><br>
     <label>username:</label><input type="text"name="username"class='form-control'><br>
     <label>password:</label><input type="time" name="password"class='form-control'><br>
	 <label>BlooBank:</label><input type="time" name="blood_bank"class='form-control'><br>

   <center>  <input type="submit"name="submit" class='btn btn-danger'><center>
  </form>
     <?php
     error_reporting(0);
       include("connection.php");
       if(isset($_POST['submit']))
       {

        $donorname=$_POST['donor_name'];
        $email=$_POST['email'];
        $username=$_POST['username'];
        $password=$_POST['password'];
        $bloodbank=$_POST['blood_bank'];
        
        $ins="INSERT INTO donor(donor_name',email,username,password,blood_bank)VALUES(' $donorname','$email','$username','$password',''blood_bank'')";
          $res= mysqli_query($con,$ins);
          if(res)
          {
echo "<script>
alert('inserted');

</script>";

          }

        }
     ?>


 </div>
  </body>
  </html>