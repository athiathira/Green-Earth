<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action=""method="POST"><br>
     <label>name:</label><input type="text"name="name" class='form-control'><br>
     <label>quantity:</label><input type="text"name="quantity"class='form-control'><br>
     <label>price:</label><input type="time" name="price"class='form-control'><br>
	 <label>disease:</label><input type="time" name="disease"class='form-control'><br>
     <label>symptom:</label><input type="text" name="symptom"class='form-control'><br>
     <label>stock:</label><input type="text" name="stock"class='form-control'><br>
   <center>  <input type="submit"name="submit" class='btn btn-danger'><center>
  </form>
     <?php
     error_reporting(0);
       include("connection.php");
       if(isset($_POST['submit']))
       {

        $name=$_POST['name'];
        $quantity=$_POST['quantity'];
        $price=$_POST['price'];
        $disease=$_POST['disease'];
        $symptom=$_POST['symptom'];
        $stock=$_POST['stock'];

        $ins="INSERT INTO  medicine(name',quantity,price,disease,symptom,stock)VALUES(' $name',' $quantity','$price',' $disease',' $symptom','$stock')";
          $res= mysqli_query($con,$ins);
          if(res)
          {
echo "<script>
alert('inserted');

</script>";

          }

        }
     ?>


 </div>
  </body>
  </html>