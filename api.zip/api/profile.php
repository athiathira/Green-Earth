<?php
include("header.php");
//include("connection.php");

?>

 <h4>Profile</h4>
    
    <table class="table table-striped" >
                        
                           
                              <?php
                                $con = mysqli_connect("localhost","root","","helper");  //connection query
                            
                                $sel="select * from  user where id='$id'"; 
                                    
                                $res=mysqli_query($con,$sel);
                                while($row=mysqli_fetch_array($res))
                                {


                            ?>
                            <tr>
                            <th>USER_ID</th><td><?php echo $row['user_id']?></td>
                            </tr>
                            <tr>
                            <th>NAME</th><td><?php echo $row['name']?></td>
                            </tr>
                             <tr>
                            <th>Email</th><td>
                                <?php echo $row['email']?></td>
                            </tr>
                            <tr>
                            <th>phone</th><td><?php echo $row['phone']?></td>
							 <th>bloodgroup</th><td><?php echo $row['bloodgroup']?></td>
                            </tr>
                        
                            <?php
                                }
                            
                            ?>  
                                
                            
                        </table>
