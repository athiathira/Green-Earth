<?php

$con = mysqli_connect("localhost","root","","etour");

$user_id =$_POST['userid'];
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$mobile = $_POST['mobile']; 

$sql = "INSERT INTO user_tbl(user_id,name,email,password,mobile) VALUES ('$user_id','$name','$email','$password','$mobile')";
// echo $sql;

if(mysqli_query($con,$sql))
{
	echo "success";
}
else{
	echo "failed";
}

?>